import figure

'''
The "figure" module is used to initialize the input side length value and calculate the area of each shape.
"myline = figure.Line(10)" This code is used to initialize the Line class and to assign a value "10".
The "area_square" function is used to calculate the area of a square, 
the "area_regular_triangle" function is used to calculate the area of an equilateral triangle, 
and the "area_circle" is used to calculate the area of a circle.
'''

myline = figure.Line(10)

square = figure.area_square(myline.get_length())
print("the area of a square: " + str(square))

myline.set_length(20)
regular_triangle = figure.area_regular_triangle(myline.get_length())
print("the area of an equilateral triangle: " + str(regular_triangle))

myline.set_length(30)
circle = figure.area_circle(myline.get_length())
print("the area of a circle: " + str(circle))